using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Net;
using System.Runtime.InteropServices;
using System.Management;
using System.Reflection;
/*
using System.Windows.Forms;
using System;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Text.RegularExpressions;
using System.Net.Sockets;
using Microsoft.Win32;
using System.Management;
using System.Text;*/
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace portblocking
{
    public partial class Form1 : Form
    {
        Semaphore semaphore = new Semaphore(1, 1);
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("iphlpapi.dll", ExactSpelling = true)]
        public static extern int GetExtendedUdpTable(IntPtr pUdpTable, ref int dwOutBufLen, bool sort, int ipVersion, UDP_TABLE_CLASS tblClass, int reserved);

        public enum UDP_TABLE_CLASS
        {
            UDP_TABLE_BASIC,
            UDP_TABLE_OWNER_PID,
            UDP_TABLE_OWNER_MODULE
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MIB_UDPROW_OWNER_PID
        {
            public uint localAddr;
            public byte localPort1;
            public byte localPort2;
            public byte localPort3;
            public byte localPort4;
            public int owningPid;
        }
        [DllImport("iphlpapi.dll", ExactSpelling = true)]
        public static extern int GetExtendedTcpTable(IntPtr pTcpTable, ref int dwOutBufLen, bool sort, int ipVersion, TCP_TABLE_CLASS tblClass, int reserved);

        public enum TCP_TABLE_CLASS
        {
            TCP_TABLE_BASIC_LISTENER,
            TCP_TABLE_BASIC_CONNECTIONS,
            TCP_TABLE_BASIC_ALL,
            TCP_TABLE_OWNER_PID_LISTENER,
            TCP_TABLE_OWNER_PID_CONNECTIONS,
            TCP_TABLE_OWNER_PID_ALL,
            TCP_TABLE_OWNER_MODULE_LISTENER,
            TCP_TABLE_OWNER_MODULE_CONNECTIONS,
            TCP_TABLE_OWNER_MODULE_ALL
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MIB_TCPROW_OWNER_PID
        {
            public uint state;
            public uint localAddr;
            public byte localPort1;
            public byte localPort2;
            public byte localPort3;
            public byte localPort4;
            public uint remoteAddr;
            public byte remotePort1;
            public byte remotePort2;
            public byte remotePort3;
            public byte remotePort4;
            public int owningPid;
        }

        // ���μ��� ID�� ����� ���� ��θ� �������� �޼���
        static string GetExecutablePath(int processId)
        {
            string query = $"SELECT ExecutablePath FROM Win32_Process WHERE ProcessId = {processId}";
            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(query))
            using (ManagementObjectCollection results = searcher.Get())
            {
                foreach (ManagementObject obj in results)
                {
                    return obj["ExecutablePath"]?.ToString();
                }
            }
            return null;
        }

        private void portpidbtn_Click(object sender, EventArgs e)
        {
            loadprocesstcp();
            loadprocessudp();
        }

        private void loadprocesstcp()
        {

            List<string> items2 = new List<string>();
            int AF_INET = 2;    // IP_v4
            int buffSize = 0;
            GetExtendedTcpTable(IntPtr.Zero, ref buffSize, false, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
            IntPtr tcpTablePtr = Marshal.AllocHGlobal(buffSize);
            try
            {
                string info = "";
                GetExtendedTcpTable(tcpTablePtr, ref buffSize, false, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
                int rowSize = Marshal.SizeOf(typeof(MIB_TCPROW_OWNER_PID));
                int numEntries = Marshal.ReadInt32(tcpTablePtr);
                IntPtr rowPtr = (IntPtr)((long)tcpTablePtr + Marshal.SizeOf(typeof(int)));

                for (int i = 0; i < numEntries; i++)
                {
                    MIB_TCPROW_OWNER_PID tcpRow = (MIB_TCPROW_OWNER_PID)Marshal.PtrToStructure(rowPtr, typeof(MIB_TCPROW_OWNER_PID));
                    Process process = Process.GetProcessById(tcpRow.owningPid);

                    uint stateValue = tcpRow.state; // ���� ��: 2
                    TcpState state = (TcpState)stateValue;

                    info = $"Local: {new IPAddress(tcpRow.localAddr)}, Port: {BitConverter.ToUInt16(new byte[2] { tcpRow.localPort2, tcpRow.localPort1 }, 0)} ";
                    info += $"Remote: {new IPAddress(tcpRow.remoteAddr)}, Port: {BitConverter.ToUInt16(new byte[2] { tcpRow.remotePort2, tcpRow.remotePort1 }, 0)} ";
                    info += $"state: {state.ToString()}";
                    info += $"PID: {tcpRow.owningPid}, Proc: {process.ProcessName} ";

                    //richTextBox1.AppendText($"{tcpRow.localPort1},{tcpRow.localPort2},{tcpRow.localPort3},{tcpRow.localPort4} \r\n");
                    items2.Add($"TCP,{tcpRow.owningPid},{process.ProcessName},{BitConverter.ToUInt16(new byte[2] { tcpRow.localPort2, tcpRow.localPort1 }, 0)},{BitConverter.ToUInt16(new byte[2] { tcpRow.remotePort2, tcpRow.remotePort1 }, 0)} ");

                    try
                    {
                        info += $"Path: {GetExecutablePath(process.Id)}";
                    }
                    catch (Exception ex)
                    {
                        info += ex.ToString();
                    }

                    try
                    {
                        // �޸� �ּ� ��� (���� �޸��� ���̽� �ּ�)
                        //foreach (ProcessModule module in process.Modules)
                        //{
                        //    info += $"Module: {module.ModuleName}, Base Addr: {module.BaseAddress} entry addr: {module.EntryPointAddress} mem size: {module.ModuleMemorySize} \n"; 
                        //}
                    }
                    catch (Exception ex)
                    {
                        //info += ex.ToString();
                    }
                    //richTextBox1.AppendText(info);

                    rowPtr = (IntPtr)((long)rowPtr + rowSize);
                }

                items2.Sort();
                checkedListBox1.Items.Clear();
                checkedListBox2.Items.Clear();

                string buffer = "";
                foreach (string val in items2)
                {
                    if (buffer != val.Split(',')[2])
                    {
                        checkedListBox2.Items.Add(val.Split(',')[2]);
                    }
                    checkedListBox1.Items.Add(val);
                    buffer = val.Split(',')[2];
                }

            }
            finally
            {
                Marshal.FreeHGlobal(tcpTablePtr);
            }
        }

        private void loadprocessudp()
        {
            List<string> items2 = new List<string>();
            int AF_INET = 2; // IP_v4
            int buffSize = 0;
            GetExtendedUdpTable(IntPtr.Zero, ref buffSize, false, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, 0);
            IntPtr udpTablePtr = Marshal.AllocHGlobal(buffSize);
            try
            {
                GetExtendedUdpTable(udpTablePtr, ref buffSize, false, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, 0);
                int rowSize = Marshal.SizeOf(typeof(MIB_UDPROW_OWNER_PID));
                int numEntries = Marshal.ReadInt32(udpTablePtr);
                IntPtr rowPtr = (IntPtr)((long)udpTablePtr + Marshal.SizeOf(typeof(int)));

                for (int i = 0; i < numEntries; i++)
                {
                    MIB_UDPROW_OWNER_PID udpRow = (MIB_UDPROW_OWNER_PID)Marshal.PtrToStructure(rowPtr, typeof(MIB_UDPROW_OWNER_PID));
                    Process process = Process.GetProcessById(udpRow.owningPid);

                    //UpdateRichTextBox($"Process ID: {udpRow.owningPid}, Process Name: {process.ProcessName}");
                    //UpdateRichTextBox($"Local Address: {new IPAddress(udpRow.localAddr)}, Local Port: {BitConverter.ToUInt16(new byte[2] { udpRow.localPort2, udpRow.localPort1 }, 0)}");
                    items2.Add($"UDP,{udpRow.owningPid},{process.ProcessName},{BitConverter.ToUInt16(new byte[2] { udpRow.localPort2, udpRow.localPort1 }, 0)}");
                    rowPtr = (IntPtr)((long)rowPtr + rowSize);

                    //richTextBox1.AppendText($"{udpRow.localPort1},{udpRow.localPort2},{udpRow.localPort3},{udpRow.localPort4} \r\n");
                }

                items2.Sort();
                string buffer = "";
                
                foreach (string val in items2)
                {
                    checkedListBox1.Items.Add(val);
                }

                List<string> bufferlist = new List<string>();
                foreach (string val in checkedListBox1.Items)
                {
                    if (buffer != val.Split(',')[2])
                    {
                        //checkedListBox2.Items.Add(val.Split(',')[2]);
                        bufferlist.Add(val.Split(',')[2]);
                    }
                    buffer = val.Split(',')[2];
                }


                bufferlist.Sort();
                checkedListBox2.Items.Clear();
                foreach (string buffer1 in bufferlist)
                {
                    if (buffer != buffer1)
                    {
                        checkedListBox2.Items.Add(buffer1);
                        checkedListBox2.SetItemChecked(checkedListBox2.Items.Count - 1, true);
                    }
                    buffer = buffer1;
                }

            }
            finally
            {
                Marshal.FreeHGlobal(udpTablePtr);
            }
        }

        private bool selectudppid(string pid)
        {
            List<string> items2 = new List<string>();
            int AF_INET = 2; // IP_v4
            int buffSize = 0;
            bool searched = false;
            int cnt = 0;
            GetExtendedUdpTable(IntPtr.Zero, ref buffSize, false, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, 0);
            IntPtr udpTablePtr = Marshal.AllocHGlobal(buffSize);
            try
            {
                richTextBox1.Text = "";
                GetExtendedUdpTable(udpTablePtr, ref buffSize, false, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, 0);
                int rowSize = Marshal.SizeOf(typeof(MIB_UDPROW_OWNER_PID));
                int numEntries = Marshal.ReadInt32(udpTablePtr);
                IntPtr rowPtr = (IntPtr)((long)udpTablePtr + Marshal.SizeOf(typeof(int)));

                for (int i = 0; i < numEntries; i++)
                {
                    MIB_UDPROW_OWNER_PID udpRow = (MIB_UDPROW_OWNER_PID)Marshal.PtrToStructure(rowPtr, typeof(MIB_UDPROW_OWNER_PID));
                    Process process = Process.GetProcessById(udpRow.owningPid);
                    if (pid == udpRow.owningPid.ToString())
                    {

                        richTextBox1.AppendText($"Process ID: {udpRow.owningPid}, Process Name: {process.ProcessName}");
                        richTextBox1.AppendText($"Local Address: {new IPAddress(udpRow.localAddr)}, Local Port: {BitConverter.ToUInt16(new byte[2] { udpRow.localPort2, udpRow.localPort1 }, 0)} \r\n");
                        //items2.Add($"{udpRow.owningPid},{process.ProcessName},{BitConverter.ToUInt16(new byte[2] { udpRow.localPort2, udpRow.localPort1 }, 0)}");
                        searched = true;
                    }
                    else
                    {
                        if (searched)
                        {
                            string info = "";
                            // �޸� �ּ� ��� (���� �޸��� ���̽� �ּ�)
                            foreach (ProcessModule module in process.Modules)
                            {
                                FileVersionInfo fileInfo = FileVersionInfo.GetVersionInfo(module.FileName);
                                if (fileInfo.CompanyName != "Microsoft Corporation")
                                {
                                    info += $"Module: {module.ModuleName}  mem size: {module.ModuleMemorySize} file : {module.FileName} \n";
                                    info += $"Product Name: {fileInfo.ProductName}\n";
                                    info += $"Company Name: {fileInfo.CompanyName}\n";
                                    string temp = $"Signature : {VerifyEmbeddedSignature(module.FileName)} \n\n";
                                    info += temp;
                                    cnt++;
                                }
                            }

                            richTextBox1.AppendText(info);
                            richTextBox1.AppendText($"\n cnt = {cnt} \n");
                            searched = false;
                            break;
                        }
                    }
                    //richTextBox1.AppendText($"{udpRow.localPort1},{udpRow.localPort2},{udpRow.localPort3},{udpRow.localPort4} \r\n");
                    rowPtr = (IntPtr)((long)rowPtr + rowSize);
                }


            }
            finally
            {
                Marshal.FreeHGlobal(udpTablePtr);
            }
            return true;
        }
        private bool selecttcppid(string pid)
        {
            int AF_INET = 2;    // IP_v4
            int buffSize = 0;
            GetExtendedTcpTable(IntPtr.Zero, ref buffSize, false, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
            IntPtr tcpTablePtr = Marshal.AllocHGlobal(buffSize);
            try
            {
                bool searched = false;
                string info = "";
                int cnt = 0;
                GetExtendedTcpTable(tcpTablePtr, ref buffSize, false, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
                int rowSize = Marshal.SizeOf(typeof(MIB_TCPROW_OWNER_PID));
                int numEntries = Marshal.ReadInt32(tcpTablePtr);
                IntPtr rowPtr = (IntPtr)((long)tcpTablePtr + Marshal.SizeOf(typeof(int)));
                richTextBox1.Text = "";
                for (int i = 0; i < numEntries; i++)
                {
                    MIB_TCPROW_OWNER_PID tcpRow = (MIB_TCPROW_OWNER_PID)Marshal.PtrToStructure(rowPtr, typeof(MIB_TCPROW_OWNER_PID));

                    uint stateValue = tcpRow.state; // ���� ��: 2
                    TcpState state = (TcpState)stateValue;

                    if (pid == tcpRow.owningPid.ToString())
                    {
                        info = $"Local: {new IPAddress(tcpRow.localAddr)}, Port: {BitConverter.ToUInt16(new byte[2] { tcpRow.localPort2, tcpRow.localPort1 }, 0)} ";
                        info += $"Remote: {new IPAddress(tcpRow.remoteAddr)}, Port: {BitConverter.ToUInt16(new byte[2] { tcpRow.remotePort2, tcpRow.remotePort1 }, 0)} ";
                        info += $"state: {state.ToString()} \r\n";

                        richTextBox1.AppendText(info);
                        searched = true;
                    }
                    else
                    {
                        if (searched)
                        {
                            Process process = Process.GetProcessById(tcpRow.owningPid);

                            info = $"PID: {tcpRow.owningPid}, Proc: {process.ProcessName} ";
                            try
                            {
                                info += $"Path: {GetExecutablePath(process.Id)} \n";
                            }
                            catch (Exception ex)
                            {
                                info += ex.ToString();
                            }

                            // �޸� �ּ� ��� (���� �޸��� ���̽� �ּ�)
                            foreach (ProcessModule module in process.Modules)
                            {
                                FileVersionInfo fileInfo = FileVersionInfo.GetVersionInfo(module.FileName);
                                if (fileInfo.CompanyName != "Microsoft Corporation")
                                {
                                    info += $"Module: {module.ModuleName}  mem size: {module.ModuleMemorySize} file : {module.FileName} \n";
                                    info += $"Product Name: {fileInfo.ProductName}\n";
                                    info += $"Company Name: {fileInfo.CompanyName}\n";
                                    string temp = $"Signature : {VerifyEmbeddedSignature(module.FileName)} \n\n";
                                    info += temp;
                                    cnt++;
                                }
                            }

                            richTextBox1.AppendText(info);
                            richTextBox1.AppendText($"\n cnt = {cnt} \n");
                            searched = false;
                            break;
                        }
                    }

                    rowPtr = (IntPtr)((long)rowPtr + rowSize);
                }

            }
            catch (Exception ex)
            {
                richTextBox1.AppendText(ex.ToString());
            }
            return true;
        }

        private void checkedListBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            string[] selval = checkedListBox1.SelectedItem.ToString().Split(',');
            richTextBox1.AppendText($"{selval[0]},{selval[1]},{selval[2]},{selval[3]} \r\n");
            if (selval[0] == "TCP")
            {
                bool success = selecttcppid(selval[1]);
            }
            else if (selval[0] == "UDP")
            {
                bool success = selectudppid(selval[1]);
            }
        }

        private void killprocessbtn_Click(object sender, EventArgs e)
        {
            string[] value = checkedListBox1.SelectedItem.ToString().Split(',');

            int pid = int.Parse(value[1]); // ������ ���μ����� PID

            // taskkill ���� ����
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/C taskkill /F /PID " + pid;
            startInfo.CreateNoWindow = true; // ���� ������Ʈ â �����
            startInfo.UseShellExecute = false; // ���� ������� ����

            try
            {
                Process process = Process.Start(startInfo);
                process.WaitForExit();
                richTextBox1.AppendText("���μ��� ���� �Ϸ�");
            }
            catch (Exception ex)
            {
                richTextBox1.AppendText("���μ��� ���� ����: " + ex.Message);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Process process = Process.GetCurrentProcess();     //.GetProcessesByName("Project1");
                                                               // .GetCurrentProcess();

            string info = "";
            int cnt = 0;

            foreach (ProcessModule module in process.Modules)
            {//Module: {module.ModuleName}  
                //string description = GetModuleDescription(module.FileName);
                FileVersionInfo fileInfo = FileVersionInfo.GetVersionInfo(module.FileName);
                if (fileInfo.CompanyName != "Microsoft Corporation")
                {
                    info += $"mem size: {module.ModuleMemorySize} file : {module.FileName} \n";
                    info += $"Product Name: {fileInfo.ProductName}\n";
                    info += $"Company Name: {fileInfo.CompanyName}\n";
                    //info += $"File Version: {fileInfo.FileVersion}\n\n";
                    //bool isSigned = VerifyEmbeddedSignature(module.FileName);
                    //info += $"The file is {(isSigned ? "signed" : "not signed")}. \n\n";
                    string temp = $"Signature : {VerifyEmbeddedSignature(module.FileName)} \n\n";
                    info += temp;

                    cnt++;
                }
            }

            richTextBox1.Text = info;
            richTextBox1.AppendText($"\n cnt = {cnt} \n");

        }

        private string GetModuleDescription(string filePath)
        {
            try
            {
                Assembly assembly = Assembly.LoadFile(filePath);
                AssemblyDescriptionAttribute descriptionAttribute = (AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(assembly, typeof(AssemblyDescriptionAttribute));

                if (descriptionAttribute == null) return "No description available";

                return descriptionAttribute.Description;
            }
            catch (Exception)
            {
                return "No description available";
            }
        }

        private string VerifyEmbeddedSignature(string fileName)
        {
            WinTrustFileInfo fileInfo = new WinTrustFileInfo(fileName);
            WinTrustData trustData = new WinTrustData(fileInfo);

            uint result = WinVerifyTrust(IntPtr.Zero, WINTRUST_ACTION_GENERIC_VERIFY_V2, ref trustData);
            if (result == 0) // ERROR_SUCCESS is 0
            {
                // Get the certificate chain
                IntPtr pCertContext = IntPtr.Zero;
                if (CertGetCertificateChain(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, CertChainPolicy.CertChainPolicyChaining, 0, IntPtr.Zero, out pCertContext))
                {
                    // Iterate through the certificate chain
                    IntPtr pCurrentCert = pCertContext;
                    string info = "";
                    while (pCurrentCert != IntPtr.Zero)
                    {
                        X509Certificate2 cert = new X509Certificate2(pCurrentCert);
                        info += $"Issuer: {cert.Issuer}\n";
                        info += $"Subject: {cert.Subject}\n";
                        info += $"Valid From: {cert.NotBefore}\n";
                        info += $"Valid To: {cert.NotAfter}\n\n";
                        // Move to the next certificate in the chain
                        pCurrentCert = CertEnumCertificatesInStore(cert.Handle, pCurrentCert);
                    }

                    CertFreeCertificateChain(pCertContext);
                    return info;
                }
                else
                {
                    return "CertGetCertificateChain failed.";
                }
            }
            else
            {
                return $"WinVerifyTrust failed with error code: {result}";
            }
        }

        [DllImport("wintrust.dll", SetLastError = true, CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        private static extern uint WinVerifyTrust(
            IntPtr hwnd,
            [MarshalAs(UnmanagedType.LPStruct)] Guid pgActionID,
            [MarshalAs(UnmanagedType.Struct)] ref WinTrustData pWVTData
        );

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        private static extern bool CertGetCertificateChain(
            IntPtr hChainEngine,
            IntPtr pCertContext,
            IntPtr pTime,
            IntPtr hAdditionalStore,
            CertChainPolicy chainPolicy,
            uint dwFlags,
            IntPtr pvReserved,
            out IntPtr ppChainContext
        );

        [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr CertEnumCertificatesInStore(
            IntPtr hCertStore,
            IntPtr pPrevCertContext
        );

        [DllImport("crypt32.dll", SetLastError = true)]
        private static extern bool CertFreeCertificateChain(IntPtr pChainContext);

        private const int INVALID_HANDLE_VALUE = -1;
        private static readonly Guid WINTRUST_ACTION_GENERIC_VERIFY_V2 = new Guid("00A00000-0000-0000-C000-000000000046");

        private struct WinTrustFileInfo
        {
            public uint StructSize;
            public IntPtr pszFilePath;
            public IntPtr hFile;
            public IntPtr pgKnownSubject;

            public WinTrustFileInfo(string filePath)
            {
                StructSize = (uint)Marshal.SizeOf(typeof(WinTrustFileInfo));
                pszFilePath = Marshal.StringToCoTaskMemAuto(filePath);
                hFile = IntPtr.Zero;
                pgKnownSubject = IntPtr.Zero;
            }
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct WinTrustData
        {
            public uint StructSize;
            public IntPtr PolicyCallbackData;
            public IntPtr SIPClientData;
            public uint UIChoice;
            public uint RevocationChecks;
            public uint UnionChoice;
            public IntPtr FileInfoPtr;
            public uint StateAction;
            public IntPtr StateData;
            public string URLReference;
            public uint ProvFlags;
            public uint UIContext;

            public WinTrustData(WinTrustFileInfo fileInfo)
            {
                StructSize = (uint)Marshal.SizeOf(typeof(WinTrustData));
                PolicyCallbackData = IntPtr.Zero;
                SIPClientData = IntPtr.Zero;
                UIChoice = 2; // WTD_UI_NONE
                RevocationChecks = 1; // WTD_REVOKE_NONE
                UnionChoice = 1; // WTD_CHOICE_FILE
                FileInfoPtr = Marshal.AllocCoTaskMem(Marshal.SizeOf(typeof(WinTrustFileInfo)));
                Marshal.StructureToPtr(fileInfo, FileInfoPtr, false);
                StateAction = 0; // WTD_STATEACTION_IGNORE
                StateData = IntPtr.Zero;
                URLReference = null;
                ProvFlags = 0x00000010; // WTD_SAFER_FLAG
                UIContext = 0; // WTD_UICONTEXT_EXECUTE
            }
        }

        private enum CertChainPolicy
        {
            CertChainPolicyBase = 1,
            CertChainPolicyChaining = 2,
            CertChainPolicyEndEntity = 3
        }

        //await BlockPortInFirewall("in", "TCP", port);
        public async Task BlockPortInFirewall(string dir, string protocol, int port)
        {
            semaphore.WaitOne();

            string ruleName = $"Block {protocol} direction {dir} Port {port}";
            string localport = "";
            if (dir == "in")
            {
                localport = "localport";
            }
            else
            {
                localport = "remoteport";
            }

            if (dir != "in" && protocol=="TCP")
            {
                localport = "localport";
            }

            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            Process process = new Process();

            processStartInfo.FileName = "cmd.exe";
            processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            processStartInfo.CreateNoWindow = true;
            processStartInfo.UseShellExecute = false;
            processStartInfo.RedirectStandardOutput = true;
            processStartInfo.RedirectStandardInput = true;
            processStartInfo.RedirectStandardError = true;
            process.EnableRaisingEvents = false;
            process.StartInfo = processStartInfo;
            process.Start();

            // ��ȭ�� ��å ���� (������ ��å�� ��� �߰��Ǵ� ���� �����ϱ� ����)
            process.StandardInput.WriteLine($"netsh advfirewall firewall delete rule name=\"{ruleName}\"");

            // ��ȭ�� ��å �߰�
            process.StandardInput.WriteLine($"netsh advfirewall firewall add rule name=\"{ruleName}\" dir={dir} action=block protocol={protocol} {localport}={port}");

            process.StandardInput.Close();

            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();

            process.WaitForExit();
            process.Close();

            if (!string.IsNullOrEmpty(output))
            {
                richTextBox1.AppendText(output);
            }

            if (!string.IsNullOrEmpty(error))
            {
                richTextBox1.AppendText("Error: " + error);
            }

            semaphore.Release();
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            int cnt = 0;
            foreach (string buffer in checkedListBox2.CheckedItems)
            {
                int AF_INET = 2;    // IP_v4
                int buffSize = 0;
                GetExtendedTcpTable(IntPtr.Zero, ref buffSize, false, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
                IntPtr tcpTablePtr = Marshal.AllocHGlobal(buffSize);
                try
                {
                    bool searched = false;

                    GetExtendedTcpTable(tcpTablePtr, ref buffSize, false, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
                    int rowSize = Marshal.SizeOf(typeof(MIB_TCPROW_OWNER_PID));
                    int numEntries = Marshal.ReadInt32(tcpTablePtr);
                    IntPtr rowPtr = (IntPtr)((long)tcpTablePtr + Marshal.SizeOf(typeof(int)));

                    for (int i = 0; i < numEntries; i++)
                    {
                        MIB_TCPROW_OWNER_PID tcpRow = (MIB_TCPROW_OWNER_PID)Marshal.PtrToStructure(rowPtr, typeof(MIB_TCPROW_OWNER_PID));

                        uint stateValue = tcpRow.state; // ���� ��: 2
                        TcpState state = (TcpState)stateValue;

                        Process process = Process.GetProcessById(tcpRow.owningPid);

                        if (buffer == process.ProcessName)
                        {
                            int port = BitConverter.ToUInt16(new byte[2] { tcpRow.localPort2, tcpRow.localPort1 }, 0);
                            await BlockPortInFirewall("in", "TCP", port);
                            await BlockPortInFirewall("out", "TCP", port);
                            cnt++;
                        }
                        rowPtr = (IntPtr)((long)rowPtr + rowSize);
                    }
                }
                catch (Exception ex)
                {

                }

                GetExtendedUdpTable(IntPtr.Zero, ref buffSize, false, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, 0);
                IntPtr udpTablePtr = Marshal.AllocHGlobal(buffSize);
                try
                {
                    //richTextBox1.Text = "";
                    GetExtendedUdpTable(udpTablePtr, ref buffSize, false, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, 0);
                    int rowSize = Marshal.SizeOf(typeof(MIB_UDPROW_OWNER_PID));
                    int numEntries = Marshal.ReadInt32(udpTablePtr);
                    IntPtr rowPtr = (IntPtr)((long)udpTablePtr + Marshal.SizeOf(typeof(int)));

                    for (int i = 0; i < numEntries; i++)
                    {
                        MIB_UDPROW_OWNER_PID udpRow = (MIB_UDPROW_OWNER_PID)Marshal.PtrToStructure(rowPtr, typeof(MIB_UDPROW_OWNER_PID));
                        Process process = Process.GetProcessById(udpRow.owningPid);
                        if (buffer == process.ProcessName)
                        {
                            int port = BitConverter.ToUInt16(new byte[2] { udpRow.localPort2, udpRow.localPort1 }, 0);

                            await BlockPortInFirewall("in", "UDP", port);
                            cnt++;
                        }
                        rowPtr = (IntPtr)((long)rowPtr + rowSize);
                    }

                }
                catch (Exception ex)
                {

                }

                richTextBox1.AppendText($"=== {cnt} \r\n");
            }
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            richTextBox2.ScrollToCaret();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.ScrollToCaret();
        }
    }
}

//dotnet publish -r win-x64 -c Release /p:PublishSingleFile=true /p:SelfContained=false






