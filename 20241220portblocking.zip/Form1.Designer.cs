﻿namespace portblocking
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            portpidbtn = new Button();
            killprocessbtn = new Button();
            button3 = new Button();
            richTextBox1 = new RichTextBox();
            checkedListBox1 = new CheckedListBox();
            button1 = new Button();
            richTextBox2 = new RichTextBox();
            checkedListBox2 = new CheckedListBox();
            SuspendLayout();
            // 
            // portpidbtn
            // 
            portpidbtn.Location = new Point(12, 12);
            portpidbtn.Name = "portpidbtn";
            portpidbtn.Size = new Size(75, 23);
            portpidbtn.TabIndex = 0;
            portpidbtn.Text = "port pid";
            portpidbtn.UseVisualStyleBackColor = true;
            portpidbtn.Click += portpidbtn_Click;
            // 
            // killprocessbtn
            // 
            killprocessbtn.Location = new Point(93, 12);
            killprocessbtn.Name = "killprocessbtn";
            killprocessbtn.Size = new Size(75, 23);
            killprocessbtn.TabIndex = 1;
            killprocessbtn.Text = "kill process";
            killprocessbtn.UseVisualStyleBackColor = true;
            killprocessbtn.Click += killprocessbtn_Click;
            // 
            // button3
            // 
            button3.Location = new Point(794, 12);
            button3.Name = "button3";
            button3.Size = new Size(108, 23);
            button3.TabIndex = 2;
            button3.Text = "firewall unselect";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(255, 41);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(533, 262);
            richTextBox1.TabIndex = 4;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Location = new Point(12, 41);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(237, 400);
            checkedListBox1.TabIndex = 5;
            checkedListBox1.MouseDoubleClick += checkedListBox1_MouseDoubleClick;
            // 
            // button1
            // 
            button1.Location = new Point(908, 12);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 6;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            richTextBox2.Location = new Point(255, 309);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(533, 129);
            richTextBox2.TabIndex = 7;
            richTextBox2.Text = "다음 작업목표 후이즈라이브러리 활용 방화벽 프로세스 킬 라이브러리 분석 악성코드 백신용 샘플";
            richTextBox2.TextChanged += richTextBox2_TextChanged;
            // 
            // checkedListBox2
            // 
            checkedListBox2.FormattingEnabled = true;
            checkedListBox2.Location = new Point(794, 41);
            checkedListBox2.Name = "checkedListBox2";
            checkedListBox2.Size = new Size(242, 256);
            checkedListBox2.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 450);
            Controls.Add(checkedListBox2);
            Controls.Add(richTextBox2);
            Controls.Add(button1);
            Controls.Add(checkedListBox1);
            Controls.Add(richTextBox1);
            Controls.Add(button3);
            Controls.Add(killprocessbtn);
            Controls.Add(portpidbtn);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button portpidbtn;
        private Button killprocessbtn;
        private Button button3;
        private RichTextBox richTextBox1;
        private CheckedListBox checkedListBox1;
        private Button button1;
        private RichTextBox richTextBox2;
        private CheckedListBox checkedListBox2;
    }
}
